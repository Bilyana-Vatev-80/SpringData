package entities.billsPaymentSystem;

public enum CardType {
    GOLD,SILVER;
}
